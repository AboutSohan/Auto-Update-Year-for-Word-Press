/**
Plugin Name: Auto Update Year in Post Titles
Plugin URI: https://sohanoor.com/
Description: Automatically updates the year in post titles to the current year when the post is saved.
Version: 1.0
Author: Sohanoor Rahman
Author URI: https://www.linkedin.com/in/aboutsohan/
License: GPL2
 */

***********

Keep your year-based blog post title updated and evergreen automatically.

KEY FEATURES 🔥
1. This plugin allows you to keep updating your post year automatically.

2. You can also exclude any posts that do not update automatically.

Visit GitHub for any support: https://github.com/AboutSohan/Auto-Update-Year-for-Word-Press