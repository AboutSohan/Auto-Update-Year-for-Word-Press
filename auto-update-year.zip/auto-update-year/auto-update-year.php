<?php
/**
Plugin Name: Auto Update Year in Post Titles
Plugin URI: https://sohanoor.com/
Description: Automatically updates the year in post titles to the current year when the post is saved.
Version: 1.0
Author: Sohanoor Rahman
Author URI: https://www.linkedin.com/in/aboutsohan/
License: GPL2
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Dynamic_Year_Title {
    
    public function __construct() {
        // Hook into the title filter
        add_filter('the_title', array($this, 'update_year_in_title'), 10, 2);
        
        // Add settings page
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Add meta box for exclusion
        add_action('add_meta_boxes', array($this, 'add_exclusion_meta_box'));
        add_action('save_post', array($this, 'save_exclusion_meta_box'));
    }
    
    /**
     * Updates the year in the post title
     */
    public function update_year_in_title($title, $post_id = null) {
        // Don't modify titles in admin area
        if (is_admin()) {
            return $title;
        }
        
        // Check if this post is excluded
        if ($post_id && get_post_meta($post_id, '_exclude_dynamic_year', true)) {
            return $title;
        }
        
        // Get plugin settings
        $settings = get_option('dynamic_year_settings', array(
            'year_format' => 'YYYY',
            'enabled_post_types' => array('post')
        ));
        
        // Check if we should process this post type
        if ($post_id) {
            $post_type = get_post_type($post_id);
            if (!in_array($post_type, $settings['enabled_post_types'])) {
                return $title;
            }
        }
        
        // Regular expression to match year patterns
        $year_patterns = array(
            '/\b20\d{2}\b/', // Matches years like 2023
            '/\b\d{4}\b/',   // Matches any 4-digit number
            '/\bYYYY\b/'     // Matches YYYY placeholder
        );
        
        $current_year = date('Y');
        
        // Replace all year patterns with current year
        foreach ($year_patterns as $pattern) {
            $title = preg_replace($pattern, $current_year, $title);
        }
        
        return $title;
    }
    
    /**
     * Adds the meta box for excluding posts
     */
    public function add_exclusion_meta_box() {
        $settings = get_option('dynamic_year_settings', array(
            'enabled_post_types' => array('post')
        ));
        
        foreach ($settings['enabled_post_types'] as $post_type) {
            add_meta_box(
                'dynamic_year_exclusion',
                'Dynamic Year Settings',
                array($this, 'render_exclusion_meta_box'),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * Renders the exclusion meta box
     */
    public function render_exclusion_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('dynamic_year_exclusion', 'dynamic_year_exclusion_nonce');
        
        $excluded = get_post_meta($post->ID, '_exclude_dynamic_year', true);
        ?>
        <label>
            <input type="checkbox" 
                   name="exclude_dynamic_year" 
                   value="1" 
                   <?php checked($excluded, '1'); ?>>
            Exclude this post from dynamic year updates
        </label>
        <p class="description">
            Check this box to prevent the year in this post's title from being automatically updated.
        </p>
        <?php
    }
    
    /**
     * Saves the exclusion meta box data
     */
    public function save_exclusion_meta_box($post_id) {
        // Security checks
        if (!isset($_POST['dynamic_year_exclusion_nonce'])) {
            return;
        }
        
        if (!wp_verify_nonce($_POST['dynamic_year_exclusion_nonce'], 'dynamic_year_exclusion')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Save the exclusion setting
        $excluded = isset($_POST['exclude_dynamic_year']) ? '1' : '';
        update_post_meta($post_id, '_exclude_dynamic_year', $excluded);
    }
    
    /**
     * Adds the settings page to WordPress admin
     */
    public function add_settings_page() {
        add_options_page(
            'Dynamic Year Title Settings',
            'Dynamic Year Title',
            'manage_options',
            'dynamic-year-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Registers the plugin settings
     */
    public function register_settings() {
        register_setting('dynamic_year_settings', 'dynamic_year_settings');
        
        add_settings_section(
            'dynamic_year_main_section',
            'Main Settings',
            null,
            'dynamic-year-settings'
        );
        
        add_settings_field(
            'enabled_post_types',
            'Enabled Post Types',
            array($this, 'render_post_types_field'),
            'dynamic-year-settings',
            'dynamic_year_main_section'
        );
    }
    
    /**
     * Renders the settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('dynamic_year_settings');
                do_settings_sections('dynamic-year-settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Renders the post types selection field
     */
    public function render_post_types_field() {
        $settings = get_option('dynamic_year_settings', array(
            'enabled_post_types' => array('post')
        ));
        
        $post_types = get_post_types(array('public' => true), 'objects');
        
        foreach ($post_types as $post_type) {
            $checked = in_array($post_type->name, $settings['enabled_post_types']) ? 'checked' : '';
            ?>
            <label>
                <input type="checkbox" 
                       name="dynamic_year_settings[enabled_post_types][]" 
                       value="<?php echo esc_attr($post_type->name); ?>"
                       <?php echo $checked; ?>>
                <?php echo esc_html($post_type->label); ?>
            </label><br>
            <?php
        }
    }
}

// Initialize the plugin
new Dynamic_Year_Title();